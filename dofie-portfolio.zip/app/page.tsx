"use client"

import { useState, useEffect, useRef, useCallback, useMemo, memo } from "react"
import {
  Github,
  MessageCircle,
  ChevronDown,
  Volume2,
  Bot,
  Code,
  Palette,
  Terminal,
  Cpu,
  Database,
  Globe,
  Zap,
  Menu,
  X,
  Star,
  Hexagon,
  Triangle,
  Power,
  Wifi,
  Activity,
} from "lucide-react"

interface Particle {
  id: number
  x: number
  y: number
  vx: number
  vy: number
  life: number
  maxLife: number
  size: number
  color: string
  type: "spark" | "glow" | "trail" | "float"
}

interface FloatingElement {
  id: number
  x: number
  y: number
  vx: number
  vy: number
  rotation: number
  rotationSpeed: number
  size: number
  opacity: number
  type: "code" | "hex" | "binary" | "symbol"
  content: string
}

interface MatrixChar {
  x: number
  y: number
  char: string
  speed: number
  opacity: number
}

interface TerminalLog {
  id: number
  text: string
  type: "info" | "success" | "warning" | "error"
  timestamp: string
}

// Optimized memoized components
const MemoizedIcon = memo(({ icon: Icon, className, style }: { icon: any; className: string; style?: any }) => (
  <Icon className={className} style={style} />
))

const MemoizedParticle = memo(({ particle }: { particle: Particle }) => (
  <div
    className="absolute rounded-full pointer-events-none"
    style={{
      left: particle.x,
      top: particle.y,
      width: particle.size,
      height: particle.size,
      backgroundColor: particle.color,
      opacity: particle.life / particle.maxLife,
      transform: "translate(-50%, -50%)",
      boxShadow: `0 0 ${particle.size * 2}px ${particle.color}`,
    }}
  />
))

const MemoizedFloatingElement = memo(
  ({ element, scrollOffset }: { element: FloatingElement; scrollOffset: number }) => (
    <div
      className="absolute text-cyan-400/40 font-mono text-xs select-none pointer-events-none"
      style={{
        left: element.x,
        top: element.y - scrollOffset * 0.1,
        transform: `rotate(${element.rotation}deg) scale(${1 + Math.sin(Date.now() * 0.001 + element.id) * 0.1})`,
        opacity: element.opacity,
        fontSize: element.type === "code" ? "8px" : `${element.size}px`,
        textShadow: "0 0 8px currentColor",
      }}
    >
      {element.content}
    </div>
  ),
)

const MemoizedTerminalLog = memo(({ log }: { log: TerminalLog }) => (
  <div
    className={`flex items-start space-x-2 animate-fadeIn ${
      log.type === "success"
        ? "text-green-400"
        : log.type === "warning"
          ? "text-yellow-400"
          : log.type === "error"
            ? "text-red-400"
            : "text-cyan-400"
    }`}
  >
    <span className="text-gray-500 text-xs">[{log.timestamp}]</span>
    <span className="flex-1">{log.text}</span>
    {log.type === "success" && <span className="text-green-400">✔</span>}
    {log.type === "warning" && <span className="text-yellow-400">⚠</span>}
    {log.type === "error" && <span className="text-red-400">✖</span>}
  </div>
))

// Optimized throttle function
const throttle = (func: Function, limit: number) => {
  let inThrottle: boolean
  return function (this: any, ...args: any[]) {
    if (!inThrottle) {
      func.apply(this, args)
      inThrottle = true
      setTimeout(() => (inThrottle = false), limit)
    }
  }
}

export default function Portfolio() {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })
  const [isHovered, setIsHovered] = useState(false)
  const [currentSection, setCurrentSection] = useState(0)
  const [glitchText, setGlitchText] = useState("ZORO")
  const [typewriterText, setTypewriterText] = useState("")
  const [currentQuote, setCurrentQuote] = useState(0)
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [particles, setParticles] = useState<Particle[]>([])
  const [floatingElements, setFloatingElements] = useState<FloatingElement[]>([])
  const [cursorTrail, setCursorTrail] = useState<Array<{ x: number; y: number; opacity: number }>>([])
  const [scrollY, setScrollY] = useState(0)
  const [hoveredCard, setHoveredCard] = useState<number | null>(null)
  const [cursorVariant, setCursorVariant] = useState<"default" | "hover" | "click">("default")
  const [terminalLogs, setTerminalLogs] = useState<TerminalLog[]>([])
  const [isTerminalActive, setIsTerminalActive] = useState(false)

  const sectionsRef = useRef<HTMLDivElement[]>([])
  const particleIdRef = useRef(0)
  const elementIdRef = useRef(0)
  const audioContextRef = useRef<AudioContext | null>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const matrixCharsRef = useRef<MatrixChar[]>([])
  const terminalLogIdRef = useRef(0)

  const sections = useMemo(() => ["hero", "about", "projects", "skills", "quotes", "contact"], [])

  const quotes = useMemo(
    () => [
      "> Turning caffeine into code since 2069...",
      "> In the matrix, there are no bugs, only features...",
      "> Code is poetry written in logic...",
      "> Breaking systems to build better ones...",
      "> Digital chaos is my natural habitat...",
      "> Reality is just poorly optimized code...",
      "> I speak fluent binary and sarcasm...",
    ],
    [],
  )

  const aboutText = useMemo(
    () =>
      "Hello, I'm Sakar Adhikari, aka DoFiie. I'm a digital architect crafting experiences in the intersection of chaos and creativity. When I'm not building Discord bots that question reality or creating music visualizations that bend space-time, you'll find me experimenting with AI, breaking things that shouldn't be broken, and turning wild ideas into working code.",
    [],
  )

  const codeSnippets = useMemo(
    () => [
      "const chaos = () => magic",
      "while(true) { create(); }",
      "if(broken) { fix(); }",
      "function reality() { return null; }",
      "console.log('hello world');",
      "npm install universe",
      "git commit -m 'break everything'",
      "sudo rm -rf problems",
      "import { chaos } from 'reality'",
      "export default Madness",
    ],
    [],
  )

  const hexSymbols = useMemo(() => ["⬢", "⬡", "⬟", "⬠", "⬞", "⬝", "⬢", "⬡"], [])
  const binaryStrings = useMemo(
    () => ["01001000", "01100101", "01101100", "01101100", "01101111", "01010111", "01001111", "01010010"],
    [],
  )
  const symbols = useMemo(() => ["◆", "◇", "◈", "◉", "◎", "●", "○", "◐", "◑", "◒", "◓", "▲", "▼", "◀", "▶"], [])
  const matrixChars = useMemo(
    () =>
      "アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲン0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ",
    [],
  )

  // Optimized sound system
  const playSound = useCallback((type: "hover" | "click" | "success" | "error" | "beep", volume = 0.08) => {
    if (!audioContextRef.current) {
      try {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)()
      } catch {
        return // Fail silently if audio context not available
      }
    }

    try {
      const oscillator = audioContextRef.current.createOscillator()
      const gainNode = audioContextRef.current.createGain()

      oscillator.connect(gainNode)
      gainNode.connect(audioContextRef.current.destination)

      let frequency = 440
      let duration = 80

      switch (type) {
        case "hover":
          frequency = 800
          duration = 60
          break
        case "click":
          frequency = 1000
          duration = 100
          break
        case "success":
          frequency = 600
          duration = 150
          break
        case "error":
          frequency = 300
          duration = 200
          break
        case "beep":
          frequency = 1200
          duration = 40
          break
      }

      oscillator.frequency.setValueAtTime(frequency, audioContextRef.current.currentTime)
      gainNode.gain.setValueAtTime(volume, audioContextRef.current.currentTime)
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContextRef.current.currentTime + duration / 1000)

      oscillator.start(audioContextRef.current.currentTime)
      oscillator.stop(audioContextRef.current.currentTime + duration / 1000)
    } catch {
      // Fail silently
    }
  }, [])

  // Optimized matrix canvas animation
  const initializeMatrix = useCallback(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    canvas.width = window.innerWidth
    canvas.height = window.innerHeight

    const columns = Math.floor(canvas.width / 20)
    const chars: MatrixChar[] = []

    for (let i = 0; i < columns; i++) {
      chars.push({
        x: i * 20,
        y: Math.random() * canvas.height,
        char: matrixChars[Math.floor(Math.random() * matrixChars.length)],
        speed: Math.random() * 2 + 1,
        opacity: Math.random() * 0.3 + 0.1,
      })
    }

    matrixCharsRef.current = chars
  }, [matrixChars])

  const animateMatrix = useCallback(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    ctx.fillStyle = "rgba(11, 15, 25, 0.03)"
    ctx.fillRect(0, 0, canvas.width, canvas.height)

    matrixCharsRef.current.forEach((char) => {
      ctx.fillStyle = `rgba(0, 255, 238, ${char.opacity})`
      ctx.font = "14px monospace"
      ctx.fillText(char.char, char.x, char.y)

      char.y += char.speed
      if (char.y > canvas.height) {
        char.y = -20
        char.char = matrixChars[Math.floor(Math.random() * matrixChars.length)]
        char.opacity = Math.random() * 0.3 + 0.1
      }

      // Reduced star frequency
      if (Math.random() < 0.0005) {
        ctx.fillStyle = `rgba(255, 255, 255, ${Math.random() * 0.6})`
        ctx.fillRect(Math.random() * canvas.width, Math.random() * canvas.height, 1, 1)
      }
    })
  }, [matrixChars])

  // Terminal system
  const addTerminalLog = useCallback(
    (text: string, type: TerminalLog["type"] = "info") => {
      const timestamp = new Date().toLocaleTimeString()
      const newLog: TerminalLog = {
        id: terminalLogIdRef.current++,
        text,
        type,
        timestamp,
      }

      setTerminalLogs((prev) => [...prev.slice(-8), newLog])
      playSound("beep", 0.03)
    },
    [playSound],
  )

  const createParticle = useCallback((x: number, y: number, type: Particle["type"] = "spark"): Particle => {
    const colors = ["#00ffee", "#ff00ff", "#ff0066", "#00ff88", "#ffff00", "#ff6600"]
    return {
      id: particleIdRef.current++,
      x,
      y,
      vx: (Math.random() - 0.5) * 4,
      vy: (Math.random() - 0.5) * 4,
      life: type === "trail" ? 30 : 60,
      maxLife: type === "trail" ? 30 : 60,
      size: Math.random() * 3 + 1,
      color: colors[Math.floor(Math.random() * colors.length)],
      type,
    }
  }, [])

  const createFloatingElement = useCallback((): FloatingElement => {
    const types: FloatingElement["type"][] = ["code", "hex", "binary", "symbol"]
    const type = types[Math.floor(Math.random() * types.length)]
    let content = ""

    switch (type) {
      case "code":
        content = codeSnippets[Math.floor(Math.random() * codeSnippets.length)]
        break
      case "hex":
        content = hexSymbols[Math.floor(Math.random() * hexSymbols.length)]
        break
      case "binary":
        content = binaryStrings[Math.floor(Math.random() * binaryStrings.length)]
        break
      case "symbol":
        content = symbols[Math.floor(Math.random() * symbols.length)]
        break
    }

    return {
      id: elementIdRef.current++,
      x: Math.random() * window.innerWidth,
      y: Math.random() * window.innerHeight,
      vx: (Math.random() - 0.5) * 0.5,
      vy: (Math.random() - 0.5) * 0.5,
      rotation: Math.random() * 360,
      rotationSpeed: (Math.random() - 0.5) * 2,
      size: Math.random() * 20 + 8,
      opacity: Math.random() * 0.3 + 0.1,
      type,
      content,
    }
  }, [codeSnippets, hexSymbols, binaryStrings, symbols])

  // Throttled event handlers
  const handleMouseMove = useMemo(
    () =>
      throttle((e: MouseEvent) => {
        setMousePosition({ x: e.clientX, y: e.clientY })

        // Optimized cursor trail
        setCursorTrail((prev) => {
          const newTrail = [{ x: e.clientX, y: e.clientY, opacity: 1 }, ...prev.slice(0, 10)]
          return newTrail.map((point, index) => ({
            ...point,
            opacity: 1 - index / 10,
          }))
        })

        // Reduced particle creation
        if (Math.random() < 0.2) {
          setParticles((prev) => [...prev.slice(-15), createParticle(e.clientX, e.clientY, "trail")])
        }
      }, 16),
    [createParticle],
  )

  const handleClick = useCallback(
    (e: MouseEvent) => {
      setCursorVariant("click")
      setTimeout(() => setCursorVariant("default"), 150)

      // Optimized particle explosion
      for (let i = 0; i < 15; i++) {
        setParticles((prev) => [...prev, createParticle(e.clientX, e.clientY, "spark")])
      }

      playSound("click")
    },
    [createParticle, playSound],
  )

  const handleScroll = useMemo(
    () =>
      throttle(() => {
        const scrollPosition = window.scrollY
        setScrollY(scrollPosition)
        const windowHeight = window.innerHeight
        const newSection = Math.floor(scrollPosition / windowHeight)
        setCurrentSection(Math.min(newSection, sections.length - 1))
      }, 16),
    [sections.length],
  )

  useEffect(() => {
    // Initialize matrix and terminal
    initializeMatrix()

    setTimeout(() => {
      setIsTerminalActive(true)
      addTerminalLog("Initializing HACKMODE_α ...", "info")
    }, 800)

    setTimeout(() => addTerminalLog("Connected to Neon Grid 🔌", "success"), 1500)
    setTimeout(() => addTerminalLog("Loading cyberpunk.css ...", "info"), 2200)
    setTimeout(() => addTerminalLog("Projects Deployed: ✔️", "success"), 2800)
    setTimeout(() => addTerminalLog("Reality.exe has stopped working", "warning"), 3500)

    window.addEventListener("mousemove", handleMouseMove)
    window.addEventListener("click", handleClick)
    window.addEventListener("scroll", handleScroll, { passive: true })

    // Initialize floating elements
    const initialElements = Array.from({ length: 20 }, () => createFloatingElement())
    setFloatingElements(initialElements)

    // Optimized glitch effect
    const glitchInterval = setInterval(() => {
      const glitchChars = "!@#$%^&*()_+-=[]{}|;:,.<>?ΩΨΦΞΠΣΔΛΓΘΩαβγδεζηθικλμνξοπρστυφχψω"
      const original = "ZORO"
      let glitched = ""

      for (let i = 0; i < original.length; i++) {
        if (Math.random() < 0.15) {
          glitched += glitchChars[Math.floor(Math.random() * glitchChars.length)]
        } else {
          glitched += original[i]
        }
      }

      setGlitchText(glitched)
      setTimeout(() => setGlitchText("ZORO"), 120)
    }, 3500)

    // Typewriter effect
    let typewriterIndex = 0
    const typewriterInterval = setInterval(() => {
      if (typewriterIndex < aboutText.length) {
        setTypewriterText(aboutText.slice(0, typewriterIndex + 1))
        typewriterIndex++
      }
    }, 35)

    // Rotating quotes
    const quotesInterval = setInterval(() => {
      setCurrentQuote((prev) => (prev + 1) % quotes.length)
      playSound("beep", 0.02)
    }, 4500)

    // Matrix animation
    const matrixInterval = setInterval(animateMatrix, 60)

    // Optimized particle animation
    const particleInterval = setInterval(() => {
      setParticles((prev) =>
        prev
          .map((particle) => ({
            ...particle,
            x: particle.x + particle.vx,
            y: particle.y + particle.vy,
            life: particle.life - 1,
            vx: particle.vx * 0.98,
            vy: particle.vy * 0.98,
          }))
          .filter((particle) => particle.life > 0),
      )

      // Reduced random particle generation
      if (Math.random() < 0.08) {
        setParticles((prev) => [
          ...prev.slice(-20),
          createParticle(Math.random() * window.innerWidth, Math.random() * window.innerHeight, "float"),
        ])
      }
    }, 20)

    // Floating elements animation
    const elementsInterval = setInterval(() => {
      setFloatingElements((prev) =>
        prev.map((element) => ({
          ...element,
          x: element.x + element.vx,
          y: element.y + element.vy,
          rotation: element.rotation + element.rotationSpeed,
          vx: element.x > window.innerWidth ? -Math.abs(element.vx) : element.x < 0 ? Math.abs(element.vx) : element.vx,
          vy:
            element.y > window.innerHeight ? -Math.abs(element.vy) : element.y < 0 ? Math.abs(element.vy) : element.vy,
        })),
      )
    }, 80)

    // Random terminal logs
    const terminalInterval = setInterval(() => {
      const randomLogs = [
        "Scanning for vulnerabilities...",
        "Firewall bypassed successfully",
        "Downloading more RAM...",
        "Compiling universe.exe",
        "404: Sleep not found",
        "Hacking the mainframe...",
        "Coffee levels: CRITICAL",
        "Neural network training...",
        "Quantum entanglement established",
      ]

      if (Math.random() < 0.25) {
        const randomLog = randomLogs[Math.floor(Math.random() * randomLogs.length)]
        addTerminalLog(randomLog, Math.random() < 0.8 ? "info" : "success")
      }
    }, 12000)

    const handleResize = () => initializeMatrix()
    window.addEventListener("resize", handleResize)

    return () => {
      window.removeEventListener("mousemove", handleMouseMove)
      window.removeEventListener("click", handleClick)
      window.removeEventListener("scroll", handleScroll)
      window.removeEventListener("resize", handleResize)
      clearInterval(glitchInterval)
      clearInterval(typewriterInterval)
      clearInterval(quotesInterval)
      clearInterval(matrixInterval)
      clearInterval(particleInterval)
      clearInterval(elementsInterval)
      clearInterval(terminalInterval)
    }
  }, [
    createParticle,
    createFloatingElement,
    playSound,
    addTerminalLog,
    initializeMatrix,
    animateMatrix,
    handleMouseMove,
    handleClick,
    handleScroll,
    aboutText,
    quotes,
  ])

  const scrollToSection = useCallback(
    (index: number) => {
      window.scrollTo({
        top: index * window.innerHeight,
        behavior: "smooth",
      })
      setIsMenuOpen(false)
      playSound("click")
      addTerminalLog(`Navigating to section: ${sections[index]}`, "info")
    },
    [sections, playSound, addTerminalLog],
  )

  const projects = useMemo(
    () => [
      {
        title: "EchoBeatzz",
        description: "Music + visual fusion experience with real-time audio analysis and WebGL visualizations",
        tech: ["React", "Web Audio API", "Canvas", "WebGL", "Three.js"],
        icon: Volume2,
        color: "from-purple-500 via-pink-500 to-red-500",
        demo: "#",
        code: "#",
      },
      {
        title: "Clappy McSlapsYou",
        description: "Chaotic AI Discord bot that brings maximum entropy to servers with neural networks",
        tech: ["Python", "Discord.py", "OpenAI", "TensorFlow", "Chaos"],
        icon: Bot,
        color: "from-cyan-500 via-blue-500 to-indigo-500",
        demo: "#",
        code: "#",
      },
      {
        title: "Neural Nexus",
        description: "Python-powered machine learning experiments with quantum computing integration",
        tech: ["Python", "TensorFlow", "Pandas", "Jupyter", "Quantum"],
        icon: Code,
        color: "from-green-500 via-teal-500 to-cyan-500",
        demo: "#",
        code: "#",
      },
      {
        title: "Glitch.UI",
        description: "Custom React components with chaotic animations and reality-bending effects",
        tech: ["React", "Framer Motion", "CSS", "WebGL", "GLSL"],
        icon: Palette,
        color: "from-orange-500 via-red-500 to-pink-500",
        demo: "#",
        code: "#",
      },
    ],
    [],
  )

  const skills = useMemo(
    () => [
      { name: "React", level: 95, icon: Globe },
      { name: "Python", level: 90, icon: Code },
      { name: "JavaScript", level: 92, icon: Zap },
      { name: "Node.js", level: 85, icon: Cpu },
      { name: "AI/ML", level: 80, icon: Bot },
      { name: "Databases", level: 75, icon: Database },
    ],
    [],
  )

  return (
    <div className="bg-[#0b0f19] text-white overflow-x-hidden cursor-none font-mono relative">
      {/* Optimized Matrix Canvas Background */}
      <canvas
        ref={canvasRef}
        className="fixed inset-0 pointer-events-none z-0 opacity-25"
        style={{ mixBlendMode: "screen" }}
      />

      {/* Simplified Parallax Background Layers */}
      <div
        className="fixed inset-0 opacity-15 pointer-events-none"
        style={{
          transform: `translateY(${scrollY * 0.3}px)`,
          backgroundImage: `
            radial-gradient(circle at 20% 20%, rgba(0, 255, 238, 0.08) 1px, transparent 1px),
            radial-gradient(circle at 80% 80%, rgba(255, 0, 255, 0.08) 1px, transparent 1px)
          `,
          backgroundSize: "100px 100px, 150px 150px",
        }}
      />

      <div
        className="fixed inset-0 opacity-10 pointer-events-none"
        style={{
          transform: `translateY(${scrollY * 0.2}px)`,
          backgroundImage: `
            linear-gradient(45deg, transparent 40%, rgba(0, 255, 238, 0.04) 50%, transparent 60%),
            linear-gradient(-45deg, transparent 40%, rgba(255, 0, 255, 0.04) 50%, transparent 60%)
          `,
          backgroundSize: "200px 200px",
        }}
      />

      {/* Optimized Glitchy SVG Background */}
      <div className="fixed inset-0 pointer-events-none z-5">
        <svg className="w-full h-full opacity-15" viewBox="0 0 1000 1000">
          <defs>
            <linearGradient id="neonGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#00ffee" stopOpacity="0.6" />
              <stop offset="50%" stopColor="#ff00ff" stopOpacity="0.4" />
              <stop offset="100%" stopColor="#ffff00" stopOpacity="0.3" />
            </linearGradient>
          </defs>

          {/* Simplified animated shapes */}
          <polygon
            points="100,100 200,50 300,100 250,200 150,200"
            fill="url(#neonGradient)"
            className="animate-spin-slow origin-center"
            style={{ transformOrigin: "200px 125px" }}
          />
          <circle cx="700" cy="300" r="40" fill="none" stroke="#00ffee" strokeWidth="1" opacity="0.3" />
          <rect x="500" y="600" width="80" height="80" fill="none" stroke="#ff00ff" strokeWidth="1" opacity="0.2" />

          {/* Optimized animated lines */}
          <line x1="0" y1="500" x2="1000" y2="500" stroke="#00ffee" strokeWidth="1" opacity="0.15" />
          <line x1="500" y1="0" x2="500" y2="1000" stroke="#ff00ff" strokeWidth="1" opacity="0.1" />

          {/* Reduced star count */}
          {Array.from({ length: 12 }).map((_, i) => (
            <circle
              key={i}
              cx={Math.random() * 1000}
              cy={Math.random() * 1000}
              r="1"
              fill="#ffffff"
              opacity="0.4"
              className="animate-twinkle"
              style={{
                animationDelay: `${i * 0.5}s`,
                animationDuration: `${3 + Math.random() * 2}s`,
              }}
            />
          ))}
        </svg>
      </div>

      {/* Optimized Floating Elements */}
      <div className="fixed inset-0 pointer-events-none z-10">
        {floatingElements.map((element) => (
          <MemoizedFloatingElement key={element.id} element={element} scrollOffset={scrollY} />
        ))}
      </div>

      {/* Optimized Particles */}
      <div className="fixed inset-0 pointer-events-none z-20">
        {particles.slice(-25).map((particle) => (
          <MemoizedParticle key={particle.id} particle={particle} />
        ))}
      </div>

      {/* Optimized Cursor Trail */}
      <div className="fixed inset-0 pointer-events-none z-30">
        {cursorTrail.map((point, index) => (
          <div key={index}>
            <div
              className="absolute rounded-full"
              style={{
                left: point.x - 2,
                top: point.y - 2,
                width: 4 - index * 0.2,
                height: 4 - index * 0.2,
                backgroundColor: "#00ffee",
                opacity: point.opacity * 0.6,
                boxShadow: `0 0 ${8 - index}px rgba(0, 255, 238, ${point.opacity * 0.5})`,
              }}
            />
            {index < 3 && (
              <div
                className="absolute w-1 h-1 bg-white rounded-full"
                style={{
                  left: point.x + Math.sin(index) * 8,
                  top: point.y + Math.cos(index) * 8,
                  opacity: point.opacity * 0.4,
                }}
              />
            )}
          </div>
        ))}
      </div>

      {/* Optimized Custom Cursor */}
      <div
        className={`fixed pointer-events-none z-50 transition-transform duration-150 ${
          cursorVariant === "click" ? "scale-125" : cursorVariant === "hover" ? "scale-110" : "scale-100"
        }`}
        style={{
          left: mousePosition.x - 16,
          top: mousePosition.y - 16,
        }}
      >
        <div
          className={`w-8 h-8 border-2 rounded-full relative transition-all duration-200 ${
            isHovered ? "border-cyan-400" : "border-cyan-400/70"
          }`}
          style={{
            boxShadow: isHovered
              ? "0 0 20px #00ffee, inset 0 0 10px #00ffee"
              : "0 0 12px #00ffee, inset 0 0 6px #00ffee",
          }}
        >
          <div className="absolute inset-2 rounded-full bg-cyan-400/20" />
          {isHovered && <div className="absolute inset-0 rounded-full border border-purple-400/40 animate-spin" />}
          <div className="absolute inset-3 rounded-full bg-cyan-400" />
          {cursorVariant === "click" && <div className="absolute inset-0 rounded-full border-2 border-cyan-400" />}
        </div>
      </div>

      {/* Optimized Navigation */}
      <nav className="fixed top-6 right-6 z-50">
        <button
          onClick={() => {
            setIsMenuOpen(!isMenuOpen)
            playSound("click")
            addTerminalLog("Menu toggled", "info")
          }}
          className="p-4 border-2 border-cyan-400 bg-black/85 hover:bg-cyan-400/15 transition-all duration-200 relative overflow-hidden group"
          style={{
            boxShadow: "0 0 20px rgba(0, 255, 238, 0.3)",
          }}
          onMouseEnter={() => {
            setIsHovered(true)
            setCursorVariant("hover")
            playSound("hover")
          }}
          onMouseLeave={() => {
            setIsHovered(false)
            setCursorVariant("default")
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-r from-cyan-400/8 via-purple-400/8 to-pink-400/8 opacity-0 group-hover:opacity-100 transition-opacity duration-200" />
          {isMenuOpen ? (
            <MemoizedIcon icon={X} className="w-6 h-6 text-cyan-400 relative z-10" />
          ) : (
            <MemoizedIcon icon={Menu} className="w-6 h-6 text-cyan-400 relative z-10" />
          )}
        </button>

        {isMenuOpen && (
          <div className="absolute top-20 right-0 bg-black/90 border-2 border-cyan-400 p-6 space-y-3 min-w-[180px] animate-fadeIn">
            <div className="absolute inset-0 bg-gradient-to-br from-cyan-400/5 to-purple-400/5" />
            {sections.map((section, index) => (
              <button
                key={section}
                onClick={() => scrollToSection(index)}
                className="block w-full text-left px-4 py-3 text-cyan-400 hover:bg-cyan-400/15 transition-all duration-200 text-sm uppercase tracking-wider relative overflow-hidden group"
                onMouseEnter={() => {
                  setIsHovered(true)
                  setCursorVariant("hover")
                  playSound("hover")
                }}
                onMouseLeave={() => {
                  setIsHovered(false)
                  setCursorVariant("default")
                }}
              >
                <div className="absolute inset-0 bg-gradient-to-r from-cyan-400/8 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-200" />
                <div className="absolute left-0 top-0 w-1 h-full bg-cyan-400 transform scale-y-0 group-hover:scale-y-100 transition-transform duration-200" />
                <span className="relative z-10">{section}</span>
              </button>
            ))}
          </div>
        )}
      </nav>

      {/* Optimized Navigation Dots */}
      <div className="fixed left-8 top-1/2 transform -translate-y-1/2 z-40 space-y-6">
        {sections.map((_, index) => (
          <button
            key={index}
            onClick={() => scrollToSection(index)}
            className={`w-4 h-4 rounded-full border-2 transition-all duration-200 relative group ${
              currentSection === index ? "bg-cyan-400 border-cyan-400" : "border-gray-600 hover:border-cyan-400"
            }`}
            style={{
              boxShadow: currentSection === index ? "0 0 15px #00ffee" : "none",
            }}
            onMouseEnter={() => {
              setIsHovered(true)
              setCursorVariant("hover")
              playSound("hover")
            }}
            onMouseLeave={() => {
              setIsHovered(false)
              setCursorVariant("default")
            }}
          >
            {currentSection === index && (
              <>
                <div className="absolute inset-0 rounded-full bg-cyan-400 animate-ping" />
                <div className="absolute inset-1 rounded-full bg-cyan-400/50" />
              </>
            )}
          </button>
        ))}
      </div>

      {/* Hero Section */}
      <section className="min-h-screen relative overflow-hidden flex items-center justify-center">
        {/* Simplified grid background */}
        <div
          className="absolute inset-0 opacity-20"
          style={{
            transform: `translateY(${scrollY * 0.3}px)`,
            backgroundImage: `
              linear-gradient(rgba(0, 255, 238, 0.08) 1px, transparent 1px),
              linear-gradient(90deg, rgba(0, 255, 238, 0.08) 1px, transparent 1px)
            `,
            backgroundSize: "60px 60px",
          }}
        />

        {/* Optimized Scanline Effects */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="scanline" />
          <div className="scanline-vertical" />
        </div>

        {/* Floating Geometric Shapes */}
        <div className="absolute inset-0">
          {Array.from({ length: 8 }).map((_, i) => (
            <div
              key={i}
              className="absolute animate-float"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${i * 0.8}s`,
                animationDuration: `${5 + Math.random() * 3}s`,
              }}
            >
              {i % 4 === 0 && (
                <MemoizedIcon
                  icon={Hexagon}
                  className="w-3 h-3 text-cyan-400/25"
                  style={{ filter: "drop-shadow(0 0 6px currentColor)" }}
                />
              )}
              {i % 4 === 1 && (
                <MemoizedIcon
                  icon={Triangle}
                  className="w-3 h-3 text-purple-400/25"
                  style={{ filter: "drop-shadow(0 0 6px currentColor)" }}
                />
              )}
              {i % 4 === 2 && (
                <MemoizedIcon
                  icon={Star}
                  className="w-2 h-2 text-pink-400/25"
                  style={{ filter: "drop-shadow(0 0 6px currentColor)" }}
                />
              )}
              {i % 4 === 3 && (
                <div className="w-2 h-2 rounded-full bg-green-400/25" style={{ boxShadow: "0 0 8px currentColor" }} />
              )}
            </div>
          ))}
        </div>

        {/* Header Logo */}
        <div className="absolute top-6 left-6 z-30">
          <div className="flex items-center space-x-3">
            <div
              className="border-2 border-cyan-400 px-6 py-3 bg-black/85 relative overflow-hidden group hover:scale-105 transition-transform duration-200"
              style={{
                boxShadow: "0 0 20px rgba(0, 255, 238, 0.3)",
              }}
              onMouseEnter={() => {
                setIsHovered(true)
                setCursorVariant("hover")
                playSound("hover")
              }}
              onMouseLeave={() => {
                setIsHovered(false)
                setCursorVariant("default")
              }}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-cyan-400/8 via-purple-400/8 to-pink-400/8" />
              <span className="text-cyan-400 font-mono text-lg tracking-wider relative z-10 font-bold">
                Void//DoFiie
              </span>
            </div>
            <div
              className="w-0 h-0 border-l-[15px] border-l-cyan-400 border-t-[10px] border-t-transparent border-b-[10px] border-b-transparent"
              style={{ filter: "drop-shadow(0 0 8px #00ffee)" }}
            />
          </div>
        </div>

        {/* Main Content */}
        <div className="text-center z-20" style={{ transform: `translateY(${scrollY * 0.05}px)` }}>
          <div className="mb-12">
            <div className="text-cyan-400 text-2xl mb-6 tracking-widest font-bold">WELCOME TO THE GRID</div>
            <div
              className="w-48 h-48 mx-auto mb-12 rounded-full border-4 border-cyan-400 bg-gradient-to-r from-cyan-400/15 via-purple-400/15 to-pink-400/15 flex items-center justify-center relative overflow-hidden group hover:scale-105 transition-transform duration-300"
              style={{
                boxShadow: "0 0 40px rgba(0, 255, 238, 0.4), inset 0 0 20px rgba(0, 255, 238, 0.1)",
              }}
              onMouseEnter={() => {
                setIsHovered(true)
                setCursorVariant("hover")
                playSound("hover")
              }}
              onMouseLeave={() => {
                setIsHovered(false)
                setCursorVariant("default")
              }}
            >
              <div className="absolute inset-0 rounded-full bg-gradient-to-r from-cyan-400/8 via-purple-400/8 to-pink-400/8 animate-spin-slow" />
              <div className="absolute inset-0 rounded-full border-2 border-purple-400/20 animate-ping" />
              <MemoizedIcon
                icon={Terminal}
                className="w-24 h-24 text-cyan-400 relative z-10"
                style={{ filter: "drop-shadow(0 0 15px currentColor)" }}
              />
            </div>
          </div>

          <h1 className="text-7xl md:text-9xl font-bold mb-6 tracking-wider glitch-text text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 relative hover:scale-105 transition-transform duration-300">
            {glitchText}
            <div className="absolute inset-0 bg-gradient-to-r from-cyan-400/20 to-purple-400/20 blur-xl" />
          </h1>

          <h2 className="text-3xl md:text-4xl mb-6 tracking-widest text-white relative group">
            <span className="bg-gradient-to-r from-purple-400 via-pink-400 to-red-400 bg-clip-text text-transparent font-bold">
              DIGITAL ANARCHIST
            </span>
            <div className="absolute inset-0 bg-gradient-to-r from-purple-400/15 to-pink-400/15 blur-lg" />
          </h2>

          <div className="text-xl text-gray-300 mb-12 tracking-wider font-medium">
            Turning caffeine into code since 2069
          </div>

          <div className="flex justify-center space-x-12 text-lg font-mono mb-16">
            <span
              className="text-cyan-400 relative group hover:scale-105 transition-transform duration-200 cursor-pointer"
              onMouseEnter={() => {
                setIsHovered(true)
                setCursorVariant("hover")
                playSound("hover")
              }}
              onMouseLeave={() => {
                setIsHovered(false)
                setCursorVariant("default")
              }}
            >
              UNDERGROUND
              <div className="absolute inset-0 bg-cyan-400/20 blur-lg" />
              <div className="absolute -bottom-2 left-0 w-full h-0.5 bg-cyan-400 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-200" />
            </span>
            <span
              className="text-purple-400 relative group hover:scale-105 transition-transform duration-200 cursor-pointer"
              onMouseEnter={() => {
                setIsHovered(true)
                setCursorVariant("hover")
                playSound("hover")
              }}
              onMouseLeave={() => {
                setIsHovered(false)
                setCursorVariant("default")
              }}
            >
              STYLISH
              <div className="absolute inset-0 bg-purple-400/20 blur-lg" />
              <div className="absolute -bottom-2 left-0 w-full h-0.5 bg-purple-400 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-200" />
            </span>
            <span
              className="text-pink-400 relative group hover:scale-105 transition-transform duration-200 cursor-pointer"
              onMouseEnter={() => {
                setIsHovered(true)
                setCursorVariant("hover")
                playSound("hover")
              }}
              onMouseLeave={() => {
                setIsHovered(false)
                setCursorVariant("default")
              }}
            >
              CHAOTIC
              <div className="absolute inset-0 bg-pink-400/20 blur-lg" />
              <div className="absolute -bottom-2 left-0 w-full h-0.5 bg-pink-400 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-200" />
            </span>
          </div>

          <div className="animate-bounce">
            <div className="text-cyan-400 text-lg mb-4 font-bold">SCROLL TO ENTER</div>
            <MemoizedIcon
              icon={ChevronDown}
              className="w-8 h-8 text-cyan-400 mx-auto"
              style={{ filter: "drop-shadow(0 0 8px currentColor)" }}
            />
          </div>
        </div>
      </section>

      {/* About Section */}
      <section
        className="min-h-screen relative py-20 flex items-center"
        style={{ transform: `translateY(${scrollY * 0.03}px)` }}
      >
        <div className="container mx-auto px-6">
          <div className="max-w-5xl mx-auto">
            <h2 className="text-5xl md:text-7xl font-bold mb-20 text-center text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-cyan-400 relative hover:scale-105 transition-transform duration-300">
              ABOUT.EXE
              <div className="absolute inset-0 bg-gradient-to-r from-green-400/20 to-cyan-400/20 blur-xl" />
            </h2>

            <div
              className="terminal-window bg-black/85 border-2 border-green-400 p-10 relative overflow-hidden hover:scale-102 transition-transform duration-300"
              style={{
                boxShadow: "0 0 30px rgba(0, 255, 0, 0.25)",
              }}
              onMouseEnter={() => {
                setIsHovered(true)
                setCursorVariant("hover")
                playSound("hover")
              }}
              onMouseLeave={() => {
                setIsHovered(false)
                setCursorVariant("default")
              }}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-green-400/5 via-cyan-400/5 to-blue-400/5" />

              <div className="terminal-header flex items-center space-x-3 mb-8 relative z-10">
                <div className="w-3 h-3 rounded-full bg-red-500" style={{ boxShadow: "0 0 6px currentColor" }} />
                <div className="w-3 h-3 rounded-full bg-yellow-500" style={{ boxShadow: "0 0 6px currentColor" }} />
                <div className="w-3 h-3 rounded-full bg-green-500" style={{ boxShadow: "0 0 6px currentColor" }} />
                <span className="text-green-400 ml-6 text-lg font-bold">user@dofie:~$</span>
              </div>

              <div className="text-green-400 leading-relaxed font-mono relative z-10 text-lg">
                <span className="text-cyan-400 font-bold">{">"} cat about.txt</span>
                <br />
                <br />
                <div className="typewriter">
                  {typewriterText}
                  <span className="cursor animate-blink text-cyan-400">|</span>
                </div>
              </div>
            </div>

            <div className="grid md:grid-cols-4 gap-8 mt-16">
              {[
                {
                  icon: Code,
                  label: "Full Stack Dev",
                  color: "cyan",
                  desc: "Building the future",
                },
                {
                  icon: Bot,
                  label: "AI Enthusiast",
                  color: "purple",
                  desc: "Teaching machines",
                },
                {
                  icon: Palette,
                  label: "UI/UX Designer",
                  color: "pink",
                  desc: "Crafting experiences",
                },
                {
                  icon: Volume2,
                  label: "Audio Visual",
                  color: "green",
                  desc: "Sound & vision",
                },
              ].map((item, index) => (
                <div
                  key={index}
                  className={`glass-card p-8 text-center hover:scale-105 transition-transform duration-300 border-2 border-${item.color}-400/20 relative overflow-hidden group cursor-pointer`}
                  style={{
                    boxShadow: `0 0 20px rgba(0, 255, 238, 0.15)`,
                  }}
                  onMouseEnter={() => {
                    setIsHovered(true)
                    setCursorVariant("hover")
                    playSound("hover")
                  }}
                  onMouseLeave={() => {
                    setIsHovered(false)
                    setCursorVariant("default")
                  }}
                  onClick={() => {
                    playSound("click")
                    addTerminalLog(`Skill selected: ${item.label}`, "info")
                  }}
                >
                  <div className="absolute inset-0 bg-gradient-to-br from-cyan-400/8 via-purple-400/8 to-pink-400/8 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

                  <div
                    className={`text-${item.color}-400 mb-4 flex justify-center relative z-10 group-hover:scale-110 transition-transform duration-300`}
                    style={{ filter: "drop-shadow(0 0 10px currentColor)" }}
                  >
                    <MemoizedIcon icon={item.icon} className="w-10 h-10" />
                  </div>
                  <div className="text-lg font-bold text-gray-200 relative z-10 mb-2">{item.label}</div>
                  <div className="text-sm text-gray-400 relative z-10">{item.desc}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section className="min-h-screen relative py-20" style={{ transform: `translateY(${scrollY * 0.02}px)` }}>
        <div className="container mx-auto px-6">
          <h2 className="text-5xl md:text-7xl font-bold text-center mb-20 text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-400 relative hover:scale-105 transition-transform duration-300">
            PROJECTS.GRID
            <div className="absolute inset-0 bg-gradient-to-r from-cyan-400/20 to-purple-400/20 blur-xl" />
          </h2>

          <div className="grid md:grid-cols-2 gap-12 max-w-7xl mx-auto">
            {projects.map((project, index) => (
              <div
                key={index}
                className="project-card group relative border-2 border-gray-700 hover:border-cyan-400 transition-all duration-400 bg-black/50 overflow-hidden cursor-pointer"
                style={{
                  boxShadow: "0 0 20px rgba(0, 0, 0, 0.5)",
                  transform: hoveredCard === index ? "scale(1.02)" : "scale(1)",
                }}
                onMouseEnter={() => {
                  setHoveredCard(index)
                  setIsHovered(true)
                  setCursorVariant("hover")
                  playSound("hover")
                }}
                onMouseLeave={() => {
                  setHoveredCard(null)
                  setIsHovered(false)
                  setCursorVariant("default")
                }}
                onClick={() => {
                  playSound("click")
                  addTerminalLog(`Project accessed: ${project.title}`, "success")
                }}
              >
                {/* Optimized card effects */}
                <div className="absolute inset-0 bg-gradient-to-br from-cyan-400/5 via-purple-400/5 to-pink-400/5 opacity-0 group-hover:opacity-100 transition-opacity duration-400" />
                <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-400" />

                {/* Floating particles on hover */}
                {hoveredCard === index && (
                  <div className="absolute inset-0 pointer-events-none">
                    {Array.from({ length: 6 }).map((_, i) => (
                      <div
                        key={i}
                        className="absolute w-1 h-1 bg-cyan-400 rounded-full animate-float"
                        style={{
                          left: `${Math.random() * 100}%`,
                          top: `${Math.random() * 100}%`,
                          animationDelay: `${i * 0.2}s`,
                          animationDuration: "2s",
                          boxShadow: "0 0 6px currentColor",
                        }}
                      />
                    ))}
                  </div>
                )}

                <div className="p-8 relative z-10">
                  <div className="flex items-center space-x-4 mb-6">
                    <div
                      className={`p-4 rounded-lg bg-gradient-to-r ${project.color} relative overflow-hidden group-hover:scale-105 transition-transform duration-300`}
                      style={{
                        boxShadow: "0 0 15px rgba(0, 255, 238, 0.3)",
                      }}
                    >
                      <div className="absolute inset-0 bg-white/15" />
                      <div className="relative z-10" style={{ filter: "drop-shadow(0 0 6px rgba(255,255,255,0.3))" }}>
                        <MemoizedIcon icon={project.icon} className="w-6 h-6" />
                      </div>
                    </div>
                    <h3 className="text-2xl font-bold text-white group-hover:text-cyan-400 transition-colors duration-300">
                      {project.title}
                    </h3>
                  </div>

                  <p className="text-gray-300 mb-8 leading-relaxed text-lg">{project.description}</p>

                  <div className="flex flex-wrap gap-3 mb-8">
                    {project.tech.map((tech, techIndex) => (
                      <span
                        key={techIndex}
                        className="px-4 py-2 text-sm border-2 border-gray-600 text-gray-300 hover:border-cyan-400 hover:text-cyan-400 transition-all duration-300 relative overflow-hidden group/tech hover:scale-105 cursor-pointer"
                        onMouseEnter={() => playSound("hover")}
                      >
                        <div className="absolute inset-0 bg-cyan-400/8 transform scale-x-0 group-hover/tech:scale-x-100 transition-transform duration-300" />
                        <span className="relative z-10">{tech}</span>
                      </span>
                    ))}
                  </div>

                  <div className="flex space-x-6">
                    <button
                      className="flex-1 py-3 px-6 border-2 border-cyan-400 text-cyan-400 hover:bg-cyan-400 hover:text-black transition-all duration-300 text-lg font-bold relative overflow-hidden group/btn hover:scale-105"
                      onClick={(e) => {
                        e.stopPropagation()
                        playSound("click")
                        addTerminalLog(`Demo launched: ${project.title}`, "success")
                      }}
                      onMouseEnter={() => {
                        setIsHovered(true)
                        setCursorVariant("hover")
                        playSound("hover")
                      }}
                      onMouseLeave={() => {
                        setIsHovered(false)
                        setCursorVariant("default")
                      }}
                    >
                      <div className="absolute inset-0 bg-cyan-400 transform scale-x-0 group-hover/btn:scale-x-100 transition-transform duration-300" />
                      <span className="relative z-10">LIVE DEMO</span>
                    </button>
                    <button
                      className="flex-1 py-3 px-6 border-2 border-purple-400 text-purple-400 hover:bg-purple-400 hover:text-black transition-all duration-300 text-lg font-bold relative overflow-hidden group/btn hover:scale-105"
                      onClick={(e) => {
                        e.stopPropagation()
                        playSound("click")
                        addTerminalLog(`Code accessed: ${project.title}`, "success")
                      }}
                      onMouseEnter={() => {
                        setIsHovered(true)
                        setCursorVariant("hover")
                        playSound("hover")
                      }}
                      onMouseLeave={() => {
                        setIsHovered(false)
                        setCursorVariant("default")
                      }}
                    >
                      <div className="absolute inset-0 bg-purple-400 transform scale-x-0 group-hover/btn:scale-x-100 transition-transform duration-300" />
                      <span className="relative z-10">SEE CODE</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Skills Matrix Section */}
      <section className="min-h-screen relative py-20" style={{ transform: `translateY(${scrollY * 0.01}px)` }}>
        <div className="absolute inset-0 opacity-8">
          <div className="circuit-board" />
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <h2 className="text-5xl md:text-7xl font-bold text-center mb-20 text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-cyan-400 relative hover:scale-105 transition-transform duration-300">
            SKILLS.MATRIX
            <div className="absolute inset-0 bg-gradient-to-r from-green-400/20 to-cyan-400/20 blur-xl" />
          </h2>

          <div className="max-w-5xl mx-auto">
            <div className="grid md:grid-cols-2 gap-10">
              {skills.map((skill, index) => (
                <div
                  key={index}
                  className="skill-item p-8 border-2 border-gray-700 hover:border-cyan-400 transition-all duration-300 bg-black/50 relative overflow-hidden group hover:scale-105 cursor-pointer"
                  style={{
                    boxShadow: "0 0 20px rgba(0, 0, 0, 0.4)",
                  }}
                  onMouseEnter={() => {
                    setIsHovered(true)
                    setCursorVariant("hover")
                    playSound("hover")
                  }}
                  onMouseLeave={() => {
                    setIsHovered(false)
                    setCursorVariant("default")
                  }}
                  onClick={() => {
                    playSound("click")
                    addTerminalLog(`Skill analyzed: ${skill.name}`, "info")
                  }}
                >
                  <div className="absolute inset-0 bg-gradient-to-br from-cyan-400/5 via-purple-400/5 to-green-400/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

                  <div className="flex items-center space-x-6 mb-6 relative z-10">
                    <div
                      className="text-cyan-400 group-hover:scale-110 transition-transform duration-300"
                      style={{ filter: "drop-shadow(0 0 10px currentColor)" }}
                    >
                      <MemoizedIcon icon={skill.icon} className="w-5 h-5" />
                    </div>
                    <span className="text-white font-bold text-xl">{skill.name}</span>
                    <span className="text-cyan-400 ml-auto text-xl font-bold">{skill.level}%</span>
                  </div>

                  <div className="w-full bg-gray-800 h-4 rounded-full relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-r from-gray-800 to-gray-700" />
                    <div
                      className="h-4 rounded-full bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 transition-all duration-800 relative overflow-hidden"
                      style={{
                        width: `${skill.level}%`,
                        boxShadow: "0 0 15px rgba(0, 255, 238, 0.4)",
                      }}
                    >
                      <div className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent" />
                      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/15 to-transparent animate-shimmer" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Terminal Quotes Section */}
      <section
        className="min-h-screen relative py-20 flex items-center"
        style={{ transform: `translateY(${scrollY * 0.005}px)` }}
      >
        <div className="container mx-auto px-6">
          <div className="max-w-5xl mx-auto text-center">
            <h2 className="text-5xl md:text-7xl font-bold mb-20 text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400 relative hover:scale-105 transition-transform duration-300">
              TERMINAL.THOUGHTS
              <div className="absolute inset-0 bg-gradient-to-r from-purple-400/20 to-pink-400/20 blur-xl" />
            </h2>

            <div
              className="terminal-quotes bg-black/90 border-2 border-cyan-400 p-12 relative overflow-hidden hover:scale-102 transition-transform duration-300 cursor-pointer"
              style={{
                boxShadow: "0 0 40px rgba(0, 255, 238, 0.3)",
              }}
              onMouseEnter={() => {
                setIsHovered(true)
                setCursorVariant("hover")
                playSound("hover")
              }}
              onMouseLeave={() => {
                setIsHovered(false)
                setCursorVariant("default")
              }}
              onClick={() => {
                playSound("click")
                addTerminalLog("Quote accessed", "info")
              }}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-cyan-400/5 via-purple-400/5 to-pink-400/5" />

              <div
                className="text-cyan-400 text-3xl font-mono leading-relaxed relative z-10 font-bold"
                style={{ textShadow: "0 0 15px currentColor" }}
              >
                {quotes[currentQuote]}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="min-h-screen relative py-20 flex items-center">
        <div className="container mx-auto px-6">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-5xl md:text-7xl font-bold text-center mb-20 text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 relative hover:scale-105 transition-transform duration-300">
              CONNECT.EXE
              <div className="absolute inset-0 bg-gradient-to-r from-cyan-400/20 via-purple-400/20 to-pink-400/20 blur-xl" />
            </h2>

            <div
              className="glass-card p-12 border-2 border-cyan-400/40 relative overflow-hidden hover:scale-102 transition-transform duration-300"
              style={{
                boxShadow: "0 0 30px rgba(0, 255, 238, 0.25)",
              }}
              onMouseEnter={() => {
                setIsHovered(true)
                setCursorVariant("hover")
              }}
              onMouseLeave={() => {
                setIsHovered(false)
                setCursorVariant("default")
              }}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-cyan-400/5 via-purple-400/5 to-pink-400/5" />

              <form className="space-y-8 relative z-10">
                <div className="relative group">
                  <input
                    type="text"
                    placeholder="Your Name"
                    className="w-full bg-transparent border-2 border-gray-600 focus:border-cyan-400 p-5 text-white placeholder-gray-400 transition-all duration-300 text-lg hover:scale-102 focus:scale-102"
                    style={{ boxShadow: "inset 0 0 10px rgba(0, 0, 0, 0.5)" }}
                    onFocus={() => {
                      setIsHovered(true)
                      setCursorVariant("hover")
                      playSound("hover")
                      addTerminalLog("Name field focused", "info")
                    }}
                    onBlur={() => {
                      setIsHovered(false)
                      setCursorVariant("default")
                    }}
                  />
                  <div className="absolute inset-0 border-2 border-cyan-400/40 opacity-0 focus-within:opacity-100 transition-opacity duration-300 pointer-events-none" />
                </div>

                <div className="relative group">
                  <input
                    type="email"
                    placeholder="Your Email"
                    className="w-full bg-transparent border-2 border-gray-600 focus:border-cyan-400 p-5 text-white placeholder-gray-400 transition-all duration-300 text-lg hover:scale-102 focus:scale-102"
                    style={{ boxShadow: "inset 0 0 10px rgba(0, 0, 0, 0.5)" }}
                    onFocus={() => {
                      setIsHovered(true)
                      setCursorVariant("hover")
                      playSound("hover")
                      addTerminalLog("Email field focused", "info")
                    }}
                    onBlur={() => {
                      setIsHovered(false)
                      setCursorVariant("default")
                    }}
                  />
                  <div className="absolute inset-0 border-2 border-cyan-400/40 opacity-0 focus-within:opacity-100 transition-opacity duration-300 pointer-events-none" />
                </div>

                <div className="relative group">
                  <textarea
                    placeholder="Your Message"
                    rows={6}
                    className="w-full bg-transparent border-2 border-gray-600 focus:border-cyan-400 p-5 text-white placeholder-gray-400 transition-all duration-300 resize-none text-lg hover:scale-102 focus:scale-102"
                    style={{ boxShadow: "inset 0 0 10px rgba(0, 0, 0, 0.5)" }}
                    onFocus={() => {
                      setIsHovered(true)
                      setCursorVariant("hover")
                      playSound("hover")
                      addTerminalLog("Message field focused", "info")
                    }}
                    onBlur={() => {
                      setIsHovered(false)
                      setCursorVariant("default")
                    }}
                  />
                  <div className="absolute inset-0 border-2 border-cyan-400/40 opacity-0 focus-within:opacity-100 transition-opacity duration-300 pointer-events-none" />
                </div>

                <button
                  type="submit"
                  className="w-full py-5 border-2 border-cyan-400 text-cyan-400 hover:bg-cyan-400 hover:text-black transition-all duration-300 font-bold tracking-wider text-xl relative overflow-hidden group hover:scale-105"
                  style={{ boxShadow: "0 0 20px rgba(0, 255, 238, 0.3)" }}
                  onMouseEnter={() => {
                    setIsHovered(true)
                    setCursorVariant("hover")
                    playSound("hover")
                  }}
                  onMouseLeave={() => {
                    setIsHovered(false)
                    setCursorVariant("default")
                  }}
                  onClick={(e) => {
                    e.preventDefault()
                    playSound("success")
                    addTerminalLog("Message sent successfully! ✔️", "success")
                  }}
                >
                  <div className="absolute inset-0 bg-cyan-400 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300" />
                  <span className="relative z-10">SEND MESSAGE</span>
                </button>
              </form>

              <div className="flex justify-center space-x-12 mt-12">
                <a
                  href="https://github.com/ZoroOusenpai"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-6 border-2 border-cyan-400 hover:bg-cyan-400 hover:text-black transition-all duration-300 relative overflow-hidden group hover:scale-110"
                  style={{ boxShadow: "0 0 15px rgba(0, 255, 238, 0.3)" }}
                  onMouseEnter={() => {
                    setIsHovered(true)
                    setCursorVariant("hover")
                    playSound("hover")
                  }}
                  onMouseLeave={() => {
                    setIsHovered(false)
                    setCursorVariant("default")
                  }}
                  onClick={() => {
                    playSound("click")
                    addTerminalLog("GitHub profile accessed", "success")
                  }}
                >
                  <div className="absolute inset-0 bg-cyan-400 transform scale-0 group-hover:scale-100 transition-transform duration-300" />
                  <MemoizedIcon
                    icon={Github}
                    className="w-8 h-8 relative z-10"
                    style={{ filter: "drop-shadow(0 0 8px currentColor)" }}
                  />
                </a>

                <div
                  className="p-6 border-2 border-purple-400 hover:bg-purple-400 hover:text-black transition-all duration-300 cursor-pointer relative overflow-hidden group hover:scale-110"
                  style={{ boxShadow: "0 0 15px rgba(168, 85, 247, 0.3)" }}
                  title="Discord: sacar6_9"
                  onMouseEnter={() => {
                    setIsHovered(true)
                    setCursorVariant("hover")
                    playSound("hover")
                  }}
                  onMouseLeave={() => {
                    setIsHovered(false)
                    setCursorVariant("default")
                  }}
                  onClick={() => {
                    playSound("click")
                    addTerminalLog("Discord contact accessed", "success")
                  }}
                >
                  <div className="absolute inset-0 bg-purple-400 transform scale-0 group-hover:scale-100 transition-transform duration-300" />
                  <MemoizedIcon
                    icon={MessageCircle}
                    className="w-8 h-8 relative z-10"
                    style={{ filter: "drop-shadow(0 0 8px currentColor)" }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Terminal Console Section */}
      <section className="relative py-20 border-t-2 border-gray-800">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-4xl md:text-6xl font-bold text-center mb-16 text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-cyan-400 relative">
              SYSTEM.CONSOLE
              <div className="absolute inset-0 bg-gradient-to-r from-green-400/15 to-cyan-400/15 blur-lg" />
            </h2>

            <div
              className="terminal-window bg-black/90 border-2 border-green-400 p-8 relative overflow-hidden"
              style={{
                boxShadow: "0 0 25px rgba(0, 255, 0, 0.25)",
                maxHeight: "400px",
              }}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-green-400/5 to-cyan-400/5" />

              <div className="flex items-center justify-between mb-6 relative z-10">
                <div className="flex items-center space-x-3">
                  <div className="w-3 h-3 rounded-full bg-red-500" style={{ boxShadow: "0 0 6px currentColor" }} />
                  <div className="w-3 h-3 rounded-full bg-yellow-500" style={{ boxShadow: "0 0 6px currentColor" }} />
                  <div className="w-3 h-3 rounded-full bg-green-500" style={{ boxShadow: "0 0 6px currentColor" }} />
                  <span className="text-green-400 ml-4 text-sm font-bold">system@dofie-terminal</span>
                </div>

                <div className="flex items-center space-x-4 text-xs text-gray-400">
                  <div className="flex items-center space-x-1">
                    <MemoizedIcon icon={Wifi} className="w-3 h-3 text-green-400" />
                    <span>ONLINE</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <MemoizedIcon icon={Activity} className="w-3 h-3 text-cyan-400" />
                    <span>ACTIVE</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <MemoizedIcon icon={Power} className="w-3 h-3 text-purple-400" />
                    <span>POWERED</span>
                  </div>
                </div>
              </div>

              <div className="text-green-400 font-mono text-sm leading-relaxed relative z-10 overflow-y-auto max-h-80">
                <div className="mb-4">
                  <div className="text-cyan-400 mb-2">
                    <span className="text-gray-500">[{new Date().toLocaleTimeString()}]</span> System initialized
                  </div>
                  <div className="text-green-400 mb-2">
                    <span className="text-gray-500">[{new Date().toLocaleTimeString()}]</span> Welcome to DoFiie
                    Terminal v2.0.69
                  </div>
                  <div className="text-purple-400 mb-4">
                    <span className="text-gray-500">[{new Date().toLocaleTimeString()}]</span> Type 'help' for available
                    commands
                  </div>
                </div>

                <div className="space-y-1">
                  {terminalLogs.map((log) => (
                    <MemoizedTerminalLog key={log.id} log={log} />
                  ))}
                </div>

                <div className="mt-4 flex items-center space-x-2">
                  <span className="text-green-400">$</span>
                  <span className="text-white">_</span>
                  <span className="animate-blink text-cyan-400">|</span>
                </div>
              </div>
            </div>

            <div className="mt-8 grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { label: "CPU", value: "42%", color: "text-green-400", icon: Cpu },
                { label: "RAM", value: "69%", color: "text-cyan-400", icon: Database },
                { label: "NET", value: "∞", color: "text-purple-400", icon: Wifi },
                { label: "PWR", value: "MAX", color: "text-pink-400", icon: Power },
              ].map((stat, index) => (
                <div
                  key={index}
                  className="bg-black/50 border border-gray-700 p-4 text-center hover:border-cyan-400 transition-all duration-300 cursor-pointer hover:scale-105"
                  style={{ boxShadow: "0 0 10px rgba(0, 0, 0, 0.4)" }}
                  onMouseEnter={() => {
                    setIsHovered(true)
                    setCursorVariant("hover")
                    playSound("hover")
                  }}
                  onMouseLeave={() => {
                    setIsHovered(false)
                    setCursorVariant("default")
                  }}
                  onClick={() => {
                    playSound("click")
                    addTerminalLog(`System ${stat.label} checked: ${stat.value}`, "info")
                  }}
                >
                  <div className={`flex items-center justify-center space-x-2 mb-2 ${stat.color}`}>
                    <MemoizedIcon icon={stat.icon} className="w-4 h-4" />
                    <span className="text-xs font-bold">{stat.label}</span>
                  </div>
                  <div className={`text-lg font-bold ${stat.color}`}>{stat.value}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative py-12 border-t-2 border-gray-800">
        <div className="absolute inset-0 opacity-10">
          <div className="matrix-rain-small" />
        </div>

        <div className="container mx-auto px-6 text-center relative z-10">
          <div className="text-gray-400 text-lg font-mono font-bold" style={{ textShadow: "0 0 8px currentColor" }}>
            Crafted in the shadows © 2025 | DoFiie
          </div>
          <div className="mt-4 text-cyan-400/60 text-sm">&gt; Reality.exe has stopped working</div>
          <div className="mt-2 text-purple-400/40 text-xs">System uptime: ∞ days</div>
        </div>
      </footer>
    </div>
  )
}
